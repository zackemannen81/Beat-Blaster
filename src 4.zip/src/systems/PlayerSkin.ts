// systems/PlayerSkin.ts
import Phaser from 'phaser'

type ParticleEmitter = Phaser.GameObjects.Particles.ParticleEmitter
type ParticleEmitterConfig = Phaser.Types.GameObjects.Particles.ParticleEmitterConfig

export default class PlayerSkin {
  private scene: Phaser.Scene
  private host: Phaser.Types.Physics.Arcade.SpriteWithDynamicBody
  private gfx: Phaser.GameObjects.Graphics
  private trailCyan?: ParticleEmitter
  private trailPink?: ParticleEmitter
  private pulseTween?: Phaser.Tweens.Tween

  private size = 18
  private baseOffset = this.size * 1.05 // hur långt bakom mitten som trailen ska sitta

  constructor(scene: Phaser.Scene, host: Phaser.Types.Physics.Arcade.SpriteWithDynamicBody) {
    this.scene = scene
    this.host = host

    // host = fysik/kollision; dold grafik
    this.host.setVisible(false)

    // egen grafik
    this.gfx = scene.add.graphics({ x: host.x, y: host.y }).setDepth(900)
    this.drawTriangleUp(this.size)

    // följ värden (och uppdatera trail-offset/vinkel) varje frame
    scene.events.on(Phaser.Scenes.Events.UPDATE, this.follow, this)

    // se till att glow-texturer finns
    this.ensureGlowTextures()

    // partiklar
    this.createParticleEffects()

    // beat-hooks (kräver att du emittar beats till scene, se notisen längst ner)
    scene.events.on('beat:low', this.onBeatLow, this)
    scene.events.on('beat:mid', this.onBeatMid, this)
    scene.events.on('beat:high', this.onBeatHigh, this)
  }

  // ——— Triangel: spets uppåt i lokalt space, mild fill + tydlig stroke
  private drawTriangleUp(size: number) {
    const g = this.gfx
    g.clear()

    // soft glow bakom
    g.fillStyle(0x00e5ff, 0.12)
    g.fillCircle(0, 0, size + 6)

    // geometri (lite spetsig men inte galet)
    const tip = size * 0.95
    const halfBase = size * 0.50
    const baseY = size * 0.86

    // tunn semi-transparent fill (inte helt ifylld)
    g.fillStyle(0x00e5ff, 0.20)
    g.beginPath()
    g.moveTo(0, -tip)            // spets upp
    g.lineTo(-halfBase, baseY)   // bas vänster
    g.lineTo( halfBase, baseY)   // bas höger
    g.closePath()
    g.fillPath()

    // kontur för “wireframe”-känsla
    g.lineStyle(2, 0xffffff, 0.9)
    g.strokePath()
  }

  // ——— Håll grafik + trails i sync
  private follow = () => {
    this.gfx.x = this.host.x
    this.gfx.y = this.host.y
    this.gfx.rotation = this.host.rotation // din host roteras redan mot crosshair

    // framåtriktning = (0,-1) roterad med rotation
    const rot = this.gfx.rotation
    const fwX = Math.cos(rot - Math.PI / 2)
    const fwY = Math.sin(rot - Math.PI / 2)

    // bakkanten mitt = center - forward * offset
    const offX = -fwX * this.baseOffset
    const offY = -fwY * this.baseOffset

    // emitter-vinkel: bakåt relativt rotation (i grader)
    const backDeg = Phaser.Math.RadToDeg(rot) + 90
    const a = { min: backDeg - 12, max: backDeg + 12 }

    // Sätt followOffset korrekt (Phaser har ingen setFollowOffset – använd vektorn)
    if (this.trailCyan) {
      this.trailCyan.followOffset.set(offX, offY)
      this.trailCyan.setAngle(a as any) // accepterar objekt {min,max}
    }
    if (this.trailPink) {
      this.trailPink.followOffset.set(offX, offY)
      this.trailPink.setAngle(a as any)
    }
  }

  private ensureGlowTextures() {
    const makeGlow = (key: string, color: number, size = 24) => {
      if (this.scene.textures.exists(key)) return
      const g = this.scene.add.graphics({ x: 0, y: 0 }).setVisible(false)
      const cx = size / 2, cy = size / 2, r = size * 0.48, layers = 6
      for (let i = 0; i < layers; i++) {
        const t = 1 - i / layers
        g.fillStyle(color, 0.10 + 0.12 * t)
        g.fillCircle(cx, cy, r * t)
      }
      g.lineStyle(1, 0xffffff, 0.12)
      g.strokeCircle(cx, cy, r * 0.85)
      g.generateTexture(key, size, size)
      g.destroy()
    }
    makeGlow('p_glow_cyan', 0x00e5ff, 24)
    makeGlow('p_glow_pink', 0xff5db1, 24)
  }

  private createParticleEffects() {
    const hasCyan = this.scene.textures.exists('p_glow_cyan')
    const hasPink = this.scene.textures.exists('p_glow_pink')

    // Partikelconfig – vi använder follow + justerar offset i follow()
    const baseConfig: Partial<ParticleEmitterConfig> = {
      lifespan: { min: 220, max: 360 },
      speed: { min: 12, max: 26 },
      scale: { start: 0.45, end: 0 },
      alpha: { start: 0.9, end: 0 },
      quantity: 1,
      frequency: 14,
      blendMode: Phaser.BlendModes.ADD,
      follow: this.gfx,
      followOffset: { x: 0, y: 0 }   // vi ändrar med followOffset.set()
    }

    // cyan trail – huvud
    this.trailCyan = this.scene.add.particles(
      0, 0,
      hasCyan ? 'p_glow_cyan' : 'particles',
      { ...baseConfig, frame: hasCyan ? undefined : 'particle_glow_small' }
    ) as ParticleEmitter
    // djup via manager (emitter själv har inte setDepth)
    ;(this.trailCyan as any).manager?.setDepth?.(this.gfx.depth - 1)

    // rosa trail – blinkar på high-beat
    if (hasPink) {
      this.trailPink = this.scene.add.particles(0, 0, 'p_glow_pink', baseConfig) as ParticleEmitter
      ;(this.trailPink as any).manager?.setDepth?.(this.gfx.depth - 2)
      this.trailPink.stop()
    }
  }

  // ——— Pulse
  private pulse(scaleTo = 1.10, duration = 120) {
    this.pulseTween?.stop()
    this.pulseTween = this.scene.tweens.add({
      targets: this.gfx,
      scale: { from: 1, to: scaleTo },
      duration: duration / 2,
      yoyo: true,
      ease: 'Sine.easeOut'
    })
  }

  private onBeatLow = () => this.pulse(1.12, 140)
  private onBeatMid = () => this.pulse(1.08, 120)
  private onBeatHigh = () => {
    this.pulse(1.12, 140)
    if (this.trailPink && this.trailCyan) {
      this.trailCyan.stop()
      this.trailPink.start()
      this.scene.time.delayedCall(160, () => {
        this.trailPink?.stop()
        this.trailCyan?.start()
      })
    }
  }

  onHit() {
    const old = this.gfx.blendMode
    this.gfx.setBlendMode(Phaser.BlendModes.ADD)
    this.scene.time.delayedCall(80, () => this.gfx.setBlendMode(old))
    this.pulse(1.14, 90)
  }

  onDeath() {
    const usesCustom = this.scene.textures.exists('p_glow_cyan')
    const textureKey = usesCustom ? 'p_glow_cyan' : 'particles'
    const burst = this.scene.add.particles(this.gfx.x, this.gfx.y, textureKey, {
      speed: { min: 60, max: 220 },
      lifespan: { min: 300, max: 700 },
      scale: { start: 0.9, end: 0 },
      alpha: { start: 1, end: 0 },
      quantity: 12,
      angle: { min: 0, max: 360 },
      blendMode: Phaser.BlendModes.ADD,
      frame: usesCustom ? undefined : 'star_small'
    })
    this.scene.time.delayedCall(900, () => burst.destroy())
  }

  destroy() {
    this.scene.events.off(Phaser.Scenes.Events.UPDATE, this.follow, this)
    this.scene.events.off('beat:low', this.onBeatLow, this)
    this.scene.events.off('beat:mid', this.onBeatMid, this)
    this.scene.events.off('beat:high', this.onBeatHigh, this)
    this.pulseTween?.stop()
    this.trailCyan?.destroy()
    this.trailPink?.destroy()
    this.gfx.destroy()
  }
}
