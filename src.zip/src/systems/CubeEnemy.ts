import Phaser from 'phaser'

export type CubeVariant = 'solid' | 'wire' | 'plasma'

export default class CubeEnemy extends Phaser.GameObjects.Container {
  body!: Phaser.Physics.Arcade.Body
  sprite: Phaser.GameObjects.Graphics
  aura?: Phaser.GameObjects.Particles.ParticleEmitterManager
  zapTimer?: Phaser.Time.TimerEvent
  variant: CubeVariant

  constructor(
    scene: Phaser.Scene,
    x: number,
    y: number,
    variant: CubeVariant = 'solid',
    size: number = 28
  ) {
    super(scene, x, y)
    this.variant = variant

    // 1) Rita en kub (2D) med glow/outline/wire
    this.sprite = scene.add.graphics()
    this.add(this.sprite)
    this.drawCube(size)

    // 2) Variant-specifika effekter
    if (variant === 'solid') {
      this.addAura(size + 8)
    } else if (variant === 'wire') {
      this.startElectricZaps()
    } else if (variant === 'plasma') {
      this.startPlasmaPulse()
    }

    // 3) Lägg till i scen och aktivera physics
    scene.add.existing(this)
    scene.physics.add.existing(this)
    // rund body som passar ‘kvadrat’ ok för vår 2D
    this.body.setCircle(size * 0.6) // lite mindre än rutan
    this.body.setOffset(-size * 0.6, -size * 0.6)

    // 4) Idle rotation
    scene.tweens.add({
      targets: this,
      angle: { from: 0, to: 360 },
      duration: 4000,
      repeat: -1,
      ease: 'Linear'
    })
  }

  private drawCube(size: number) {
    const g = this.sprite
    g.clear()

    if (this.variant === 'solid' || this.variant === 'plasma') {
      // Fylld kvadrat + outline + enkel “shading”
      const color = (this.variant === 'plasma') ? 0x69d2ff : 0x00e5ff
      g.fillStyle(color, 0.9)
      g.fillRect(-size/2, -size/2, size, size)
      g.lineStyle(2, 0x001a33, 0.9)
      g.strokeRect(-size/2, -size/2, size, size)
      // “light sweep”
      g.lineStyle(1, 0xffffff, 0.25)
      g.beginPath()
      g.moveTo(-size/2 + 3, -size/2 + 6)
      g.lineTo(size/2 - 6, -size/2 + 6)
      g.strokePath()
    } else {
      // wireframe: bara konturer + diagonaler
      g.lineStyle(2, 0x00e5ff, 1)
      g.strokeRect(-size/2, -size/2, size, size)
      g.lineStyle(1, 0x00e5ff, 0.7)
      g.beginPath()
      g.moveTo(-size/2, -size/2); g.lineTo(size/2, size/2); g.strokePath()
      g.beginPath()
      g.moveTo(size/2, -size/2); g.lineTo(-size/2, size/2); g.strokePath()
    }
  }

  private addAura(radius: number) {
    this.aura = this.scene.add.particles(0, 0, 'particles', {
      frame: ['particle_glow_small', 'particle_circle_small'],
      speed: { min: 10, max: 20 },
      scale: { start: 0.3, end: 0 },
      alpha: { start: 0.35, end: 0 },
      lifespan: 900,
      frequency: 60,
      blendMode: 'ADD',
      emitting: true,
      radial: true,
      angle: { min: 0, max: 360 },
      speedX: { min: -10, max: 10 },
      speedY: { min: -10, max: 10 }
    })
    this.aura.setDepth(this.depth - 1)
    this.aura.startFollow(this)
  }

  private startElectricZaps() {
    // Liten slumpmässig “zap”-blink
    this.zapTimer = this.scene.time.addEvent({
      delay: 220,
      loop: true,
      callback: () => {
        const flash = this.scene.add.graphics({ x: this.x, y: this.y })
        flash.lineStyle(2, 0x66ccff, 1).setAlpha(0.9)
        // liten sicksack
        const len = 12
        flash.beginPath()
        flash.moveTo(-len, -len)
        flash.lineTo(0, -len + 4)
        flash.lineTo(len, -len)
        flash.lineTo(len - 4, 0)
        flash.lineTo(len, len)
        flash.lineTo(0, len - 4)
        flash.lineTo(-len, len)
        flash.lineTo(-len + 4, 0)
        flash.closePath()
        flash.strokePath()
        this.scene.tweens.add({
          targets: flash,
          alpha: 0,
          duration: 120,
          onComplete: () => flash.destroy()
        })
      }
    })
  }

  private startPlasmaPulse() {
    // Pulsera alpha/scale för “plasma”-känsla
    this.scene.tweens.add({
      targets: this.sprite,
      scale: { from: 0.9, to: 1.07 },
      alpha: { from: 0.8, to: 1 },
      yoyo: true,
      duration: 600,
      repeat: -1,
      ease: 'Sine.easeInOut'
    })
  }

  onHit() {
    // Liten jitter
    this.scene.tweens.add({
      targets: this,
      x: { from: this.x - 2, to: this.x + 2 },
      y: { from: this.y - 2, to: this.y + 2 },
      duration: 60,
      yoyo: true,
      repeat: 1,
      ease: 'Quad.easeOut'
    })
  }

  onDeath() {
    // Partikel-shatter
    const p = this.scene.add.particles(this.x, this.y, 'particles', {
      frame: ['particle_glow_small', 'star_small'],
      speed: { min: 60, max: 220 },
      lifespan: { min: 300, max: 800 },
      scale: { start: 0.8, end: 0 },
      alpha: { start: 1, end: 0 },
      quantity: 12,
      angle: { min: 0, max: 360 },
      blendMode: 'ADD'
    })
    this.scene.time.delayedCall(250, () => p.destroy())
  }

  destroy(fromScene?: boolean) {
    this.zapTimer?.remove(false)
    this.aura?.destroy()
    super.destroy(fromScene)
  }
}
